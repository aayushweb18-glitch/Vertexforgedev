VERTEXFORGE DIGITAL STUDIO — WEBSITE PACKAGE

Files:
- index.html: page structure and content
- style.css: responsive styling, animated artwork and transitions
- script.js: mobile navigation, scroll reveal and small interactions

Preview locally:
1. Extract the ZIP.
2. Open index.html in a modern browser.

Publish on Netlify:
1. Go to your Netlify dashboard and open the site you want to update.
2. Keep a backup of your existing site's files first.
3. Drag the extracted folder (containing index.html, style.css and script.js) into the manual deploy area, or upload it through your site's deploy workflow.
4. Check the live page on desktop and mobile after deployment.

Contact links currently use:
- Email: aayush.editor18@gmail.com
- Instagram: https://www.instagram.com/aayusharya9589/

Important:
- This package is a new front-end design; it does not automatically modify your live Netlify site.
- The contact button opens the visitor's email app using a mailto link. A backend is needed for an on-page form that submits/stores messages.
- Replace the concept service illustrations or add your real project links when ready.
